
from fastapi import FastAPI, File, UploadFile, HTTPException
import os
import uuid
from typing import Dict, Any
from tools import extract_text_from_pdf, analyze_financial_text
from celery_worker import analyze_pdf_task
from celery.result import AsyncResult

app = FastAPI(title="Financial Document Analyzer (Fixed)")

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)) -> Dict[str, Any]:
    # Save uploaded file
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")
    file_id = str(uuid.uuid4())
    file_path = os.path.join(UPLOAD_DIR, f"{file_id}.pdf")
    with open(file_path, "wb") as f:
        content = await file.read()
        f.write(content)
    try:
        text = extract_text_from_pdf(file_path)
        task = analyze_pdf_task.delay(file_path)
    return {"task_id": task.id}
        return {"filename": file.filename, "analysis": analysis}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {e}")
    finally:
        try:
            os.remove(file_path)
        except:
            pass

@app.get("/")
def root():
    return {"message": "Financial Document Analyzer (Fixed). Use POST /analyze with a PDF file."}


@app.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    result = AsyncResult(task_id)
    if result.state == "PENDING":
        return {"status": "pending"}
    elif result.state == "SUCCESS":
        return {"status": "completed", "result": result.result}
    elif result.state == "FAILURE":
        return {"status": "failed", "error": str(result.result)}
    else:
        return {"status": result.state}
