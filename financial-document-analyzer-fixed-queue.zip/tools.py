
import io
from typing import Dict, Any
from PyPDF2 import PdfReader
import re

def extract_text_from_pdf(path: str) -> str:
    """Extract text from a PDF file using PyPDF2."""
    reader = PdfReader(path)
    texts = []
    for page in reader.pages:
        texts.append(page.extract_text() or "")
    return "\n".join(texts)

def analyze_financial_text(text: str) -> Dict[str, Any]:
    """
    Simple deterministic analysis:
    - Count pages/words
    - Extract currency amounts (USD, $)
    - Find key sections like 'Risk', 'Outlook', 'Revenue'
    - Provide simple sentiment-like heuristic based on keywords
    """
    info = {}
    info["word_count"] = len(text.split())
    # Extract amounts like $1,234.56 or USD 1234
    amounts = re.findall(r"(?:USD\s?|\$)\s?[\d,]+(?:\.\d+)?", text, flags=re.IGNORECASE)
    info["amounts_found"] = amounts
    # Simple section search
    sections = {}
    for keyword in ["risk", "outlook", "revenue", "profit", "loss", "guidance", "summary", "conclusion"]:
        if re.search(rf"^\s*{keyword}", text, flags=re.IGNORECASE|re.MULTILINE):
            sections[keyword] = True
        else:
            sections[keyword] = False
    info["sections_present"] = sections
    # Heuristic sentiment
    negative_words = ["loss", "decline", "risk", "weak", "decrease"]
    positive_words = ["profit", "increase", "growth", "strong", "beat", "record"]
    neg = sum(text.lower().count(w) for w in negative_words)
    pos = sum(text.lower().count(w) for w in positive_words)
    info["heuristic_positive_score"] = pos
    info["heuristic_negative_score"] = neg
    # Short summary: pick first 500 chars
    info["summary_excerpt"] = text.strip()[:500]
    return info
