from celery import Celery
import os
from tools import extract_text_from_pdf, analyze_financial_text

# Redis broker URL (default)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

celery_app = Celery("tasks", broker=REDIS_URL, backend=REDIS_URL)

@celery_app.task
def analyze_pdf_task(file_path):
    try:
        text = extract_text_from_pdf(file_path)
        analysis = analyze_financial_text(text)
        return analysis
    except Exception as e:
        return {"error": str(e)}
